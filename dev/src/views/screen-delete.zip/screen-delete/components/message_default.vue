<style lang="scss">
  @import "./message_default";

</style>
<template>
  <div class="screen-message-default-info">
    <el-row>
      <el-col :span="24" :push="0">
        <div class="content-title content-item">当前没有通告</div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
  export default {
    components: {},
    data() {
      return {

      }
    },
    props: {

    },
    methods: {

    },
    watch: {

    },
    mounted() {

    }
  }

</script>
